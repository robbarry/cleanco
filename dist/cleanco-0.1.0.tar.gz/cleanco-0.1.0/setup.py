# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['cleanco']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'cleanco',
    'version': '0.1.0',
    'description': 'Company Name Processor written in Python',
    'long_description': '# cleanco - clean organization names\n\n![Python package](https://github.com/psolin/cleanco/workflows/Python%20package/badge.svg)\n![CodeQL](https://github.com/psolin/cleanco/workflows/CodeQL/badge.svg)\n\n## What is it / what does it do?\n\nThis is a Python package that processes company names, providing cleaned versions of the\nnames by stripping away terms indicating organization type (such as "Ltd." or "Corp").\n\nUsing a database of organization type terms, It also provides an utility to deduce the\ntype of organization, in terms of US/UK business entity types (ie. "limited liability\ncompany" or "non-profit").\n\nFinally, the system uses the term information to suggest countries the organization could\nbe established in. For example, the term "Oy" in company name suggests it is established\nin Finland, whereas "Ltd" in company name could mean UK, US or a number of other\ncountries.\n\n## How do I install it?\nJust use \'pip install cleanco\' if you have pip installed (as most systems do). Or download the zip distribution from this site, unzip it and then:\n\n* Mac: `cd` into it, and enter `sudo python setup.py install` along with your system password.\n* Windows: Same thing but without `sudo`.\n\n## How does it work?\nLet\'s look at some sample code. To get the base name of a business without legal suffix:\n\n    >>> from cleanco import basename\n    >>> business_name = "Some Big Pharma, LLC"\n    >>> basename(business_name)\n    >>> \'Some Big Pharma\'\n\nNote that sometimes a name may have e.g. two different suffixes after one another. The cleanco\nterm data covers many of these, but you may want to run `basename()` twice on the name, just in case.\n\nIf you want to use your custom terms, please see  `custom_basename()` that also provides some other ways to adjust how base name is produced.\n\nTo get the business type or country:\n\n    >>> from cleanco import typesources, matches\n    >>> classification_sources = typesources()\n    >>> matches("Some Big Pharma, LLC", classification_sources)\n    [\'Limited Liability Company\']\n\nTo get the possible countries of jurisdiction:\n\n    >>> from cleanco import countrysources, matches\n    >>> classification_sources = countrysources()\n    >>> matches("Some Big Pharma, LLC", classification_sources) ´\n    [\'United States of America\', \'Philippines\']\n\n\n## Are there bugs?\nSee the issue tracker. If you find a bug or have enhancement suggestion or question, please file an issue and provide a PR if you can. For example, some of the company suffixes may be incorrect or there may be suffixes missing.\n\nTo run tests, simply install the package and run `python setup.py test`. To run tests on multiple Python versions, install `tox` and run it (see the provided tox.ini).\n\n## Special thanks to:\n\n- Wikipedia\'s [Types of Business Entity article](http://en.wikipedia.org/wiki/Types_of_business_entity), where I spent hours of research.\n- Contributors: [Petri Savolainen](https://github.com/petri)\n',
    'author': 'None',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
